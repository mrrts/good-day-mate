var Photo = React.createClass({
  render: function(){

    return (
      <div className="card-image photo">
        <img src={this.props.filename} />
      </div>
    )
  }
})
