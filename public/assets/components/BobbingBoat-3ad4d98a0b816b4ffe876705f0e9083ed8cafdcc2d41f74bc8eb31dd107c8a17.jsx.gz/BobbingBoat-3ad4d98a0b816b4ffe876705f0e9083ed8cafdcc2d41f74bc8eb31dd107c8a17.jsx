var BobbingBoat = React.createClass({

  render: function () {
    return ( <div>
              <div id="bobbing-boat" className="bobbing">
                  <img src="/assets/boat2-cdf4bdc9bd0163fc7c301a006772469b50360365a3a58e70fc7d701b94256688.png" />
              </div>
              		<CanvasClass />
            </div>
    );
  }
});
